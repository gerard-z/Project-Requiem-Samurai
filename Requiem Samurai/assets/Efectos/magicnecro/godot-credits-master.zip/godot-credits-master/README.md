# godot-credits
A basic credits scene for use in Godot game development engine

Very low quality example:
https://imgur.com/a/HtgXv3q
